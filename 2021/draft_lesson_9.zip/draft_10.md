```python
import test
```

    __name__ value is: test



```python
import pandas as pd
```


```python
df = pd.read_csv('Homo_sapiens.gene_info', sep='\t')
```


```python
df[:3]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>9606</td>
      <td>1</td>
      <td>A1BG</td>
      <td>-</td>
      <td>A1B|ABG|GAB|HYST2477</td>
      <td>MIM:138670|HGNC:HGNC:5|Ensembl:ENSG00000121410</td>
      <td>19</td>
      <td>19q13.43</td>
      <td>alpha-1-B glycoprotein</td>
      <td>protein-coding</td>
      <td>A1BG</td>
      <td>alpha-1-B glycoprotein</td>
      <td>O</td>
      <td>alpha-1B-glycoprotein|HEL-S-163pA|epididymis s...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>1</th>
      <td>9606</td>
      <td>2</td>
      <td>A2M</td>
      <td>-</td>
      <td>A2MD|CPAMD5|FWP007|S863-7</td>
      <td>MIM:103950|HGNC:HGNC:7|Ensembl:ENSG00000175899</td>
      <td>12</td>
      <td>12p13.31</td>
      <td>alpha-2-macroglobulin</td>
      <td>protein-coding</td>
      <td>A2M</td>
      <td>alpha-2-macroglobulin</td>
      <td>O</td>
      <td>alpha-2-macroglobulin|C3 and PZP-like alpha-2-...</td>
      <td>20210316</td>
      <td>-</td>
    </tr>
    <tr>
      <th>2</th>
      <td>9606</td>
      <td>3</td>
      <td>A2MP1</td>
      <td>-</td>
      <td>A2MP</td>
      <td>HGNC:HGNC:8|Ensembl:ENSG00000256069</td>
      <td>12</td>
      <td>12p13.31</td>
      <td>alpha-2-macroglobulin pseudogene 1</td>
      <td>pseudo</td>
      <td>A2MP1</td>
      <td>alpha-2-macroglobulin pseudogene 1</td>
      <td>O</td>
      <td>pregnancy-zone protein pseudogene</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
  </tbody>
</table>
</div>




```python
df[-3:]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>61715</th>
      <td>741158</td>
      <td>8923217</td>
      <td>trnA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>tRNA</td>
      <td>tRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20200909</td>
      <td>-</td>
    </tr>
    <tr>
      <th>61716</th>
      <td>741158</td>
      <td>8923218</td>
      <td>COX1</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>cytochrome c oxidase subunit I</td>
      <td>protein-coding</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>cytochrome c oxidase subunit I</td>
      <td>20200909</td>
      <td>-</td>
    </tr>
    <tr>
      <th>61717</th>
      <td>741158</td>
      <td>8923219</td>
      <td>16S rRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>l-rRNA</td>
      <td>rRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20200909</td>
      <td>-</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>9606</td>
      <td>1</td>
      <td>A1BG</td>
      <td>-</td>
      <td>A1B|ABG|GAB|HYST2477</td>
      <td>MIM:138670|HGNC:HGNC:5|Ensembl:ENSG00000121410</td>
      <td>19</td>
      <td>19q13.43</td>
      <td>alpha-1-B glycoprotein</td>
      <td>protein-coding</td>
      <td>A1BG</td>
      <td>alpha-1-B glycoprotein</td>
      <td>O</td>
      <td>alpha-1B-glycoprotein|HEL-S-163pA|epididymis s...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>1</th>
      <td>9606</td>
      <td>2</td>
      <td>A2M</td>
      <td>-</td>
      <td>A2MD|CPAMD5|FWP007|S863-7</td>
      <td>MIM:103950|HGNC:HGNC:7|Ensembl:ENSG00000175899</td>
      <td>12</td>
      <td>12p13.31</td>
      <td>alpha-2-macroglobulin</td>
      <td>protein-coding</td>
      <td>A2M</td>
      <td>alpha-2-macroglobulin</td>
      <td>O</td>
      <td>alpha-2-macroglobulin|C3 and PZP-like alpha-2-...</td>
      <td>20210316</td>
      <td>-</td>
    </tr>
    <tr>
      <th>2</th>
      <td>9606</td>
      <td>3</td>
      <td>A2MP1</td>
      <td>-</td>
      <td>A2MP</td>
      <td>HGNC:HGNC:8|Ensembl:ENSG00000256069</td>
      <td>12</td>
      <td>12p13.31</td>
      <td>alpha-2-macroglobulin pseudogene 1</td>
      <td>pseudo</td>
      <td>A2MP1</td>
      <td>alpha-2-macroglobulin pseudogene 1</td>
      <td>O</td>
      <td>pregnancy-zone protein pseudogene</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>3</th>
      <td>9606</td>
      <td>9</td>
      <td>NAT1</td>
      <td>-</td>
      <td>AAC1|MNAT|NAT-1|NATI</td>
      <td>MIM:108345|HGNC:HGNC:7645|Ensembl:ENSG00000171428</td>
      <td>8</td>
      <td>8p22</td>
      <td>N-acetyltransferase 1</td>
      <td>protein-coding</td>
      <td>NAT1</td>
      <td>N-acetyltransferase 1</td>
      <td>O</td>
      <td>arylamine N-acetyltransferase 1|N-acetyltransf...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>4</th>
      <td>9606</td>
      <td>10</td>
      <td>NAT2</td>
      <td>-</td>
      <td>AAC2|NAT-2|PNAT</td>
      <td>MIM:612182|HGNC:HGNC:7646|Ensembl:ENSG00000156006</td>
      <td>8</td>
      <td>8p22</td>
      <td>N-acetyltransferase 2</td>
      <td>protein-coding</td>
      <td>NAT2</td>
      <td>N-acetyltransferase 2</td>
      <td>O</td>
      <td>arylamine N-acetyltransferase 2|N-acetyltransf...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>61713</th>
      <td>741158</td>
      <td>8923215</td>
      <td>trnD</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>tRNA</td>
      <td>tRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20200909</td>
      <td>-</td>
    </tr>
    <tr>
      <th>61714</th>
      <td>741158</td>
      <td>8923216</td>
      <td>trnP</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>tRNA</td>
      <td>tRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20200909</td>
      <td>-</td>
    </tr>
    <tr>
      <th>61715</th>
      <td>741158</td>
      <td>8923217</td>
      <td>trnA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>tRNA</td>
      <td>tRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20200909</td>
      <td>-</td>
    </tr>
    <tr>
      <th>61716</th>
      <td>741158</td>
      <td>8923218</td>
      <td>COX1</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>cytochrome c oxidase subunit I</td>
      <td>protein-coding</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>cytochrome c oxidase subunit I</td>
      <td>20200909</td>
      <td>-</td>
    </tr>
    <tr>
      <th>61717</th>
      <td>741158</td>
      <td>8923219</td>
      <td>16S rRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>l-rRNA</td>
      <td>rRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20200909</td>
      <td>-</td>
    </tr>
  </tbody>
</table>
</div>




```python
!pip install pandas 
!conda -y install pandas 
```


```python
df.columns
```




    Index(['#tax_id', 'GeneID', 'Symbol', 'LocusTag', 'Synonyms', 'dbXrefs',
           'chromosome', 'map_location', 'description', 'type_of_gene',
           'Symbol_from_nomenclature_authority',
           'Full_name_from_nomenclature_authority', 'Nomenclature_status',
           'Other_designations', 'Modification_date', 'Feature_type'],
          dtype='object')




```python
list(df.columns.values)
```




    ['#tax_id',
     'GeneID',
     'Symbol',
     'LocusTag',
     'Synonyms',
     'dbXrefs',
     'chromosome',
     'map_location',
     'description',
     'type_of_gene',
     'Symbol_from_nomenclature_authority',
     'Full_name_from_nomenclature_authority',
     'Nomenclature_status',
     'Other_designations',
     'Modification_date',
     'Feature_type']




```python
df['Symbol']
```




    0            A1BG
    1             A2M
    2           A2MP1
    3            NAT1
    4            NAT2
               ...   
    61713        trnD
    61714        trnP
    61715        trnA
    61716        COX1
    61717    16S rRNA
    Name: Symbol, Length: 61718, dtype: object




```python
df[['Symbol', 'GeneID']]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Symbol</th>
      <th>GeneID</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>A1BG</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>A2M</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>A2MP1</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NAT1</td>
      <td>9</td>
    </tr>
    <tr>
      <th>4</th>
      <td>NAT2</td>
      <td>10</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>61713</th>
      <td>trnD</td>
      <td>8923215</td>
    </tr>
    <tr>
      <th>61714</th>
      <td>trnP</td>
      <td>8923216</td>
    </tr>
    <tr>
      <th>61715</th>
      <td>trnA</td>
      <td>8923217</td>
    </tr>
    <tr>
      <th>61716</th>
      <td>COX1</td>
      <td>8923218</td>
    </tr>
    <tr>
      <th>61717</th>
      <td>16S rRNA</td>
      <td>8923219</td>
    </tr>
  </tbody>
</table>
<p>61718 rows × 2 columns</p>
</div>




```python
df['chromosome']
```




    0        19
    1        12
    2        12
    3         8
    4         8
             ..
    61713    MT
    61714    MT
    61715    MT
    61716    MT
    61717    MT
    Name: chromosome, Length: 61718, dtype: object




```python
df['chromosome'] == '10'
```




    0        False
    1        False
    2        False
    3        False
    4        False
             ...  
    61713    False
    61714    False
    61715    False
    61716    False
    61717    False
    Name: chromosome, Length: 61718, dtype: bool




```python
df[df['chromosome'] == '10']
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>30</th>
      <td>9606</td>
      <td>36</td>
      <td>ACADSB</td>
      <td>-</td>
      <td>2-MEBCAD|ACAD7|SBCAD</td>
      <td>MIM:600301|HGNC:HGNC:91|Ensembl:ENSG00000196177</td>
      <td>10</td>
      <td>10q26.13</td>
      <td>acyl-CoA dehydrogenase short/branched chain</td>
      <td>protein-coding</td>
      <td>ACADSB</td>
      <td>acyl-CoA dehydrogenase short/branched chain</td>
      <td>O</td>
      <td>short/branched chain specific acyl-CoA dehydro...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>49</th>
      <td>9606</td>
      <td>59</td>
      <td>ACTA2</td>
      <td>-</td>
      <td>ACTSA</td>
      <td>MIM:102620|HGNC:HGNC:130|Ensembl:ENSG00000107796</td>
      <td>10</td>
      <td>10q23.31</td>
      <td>actin alpha 2, smooth muscle</td>
      <td>protein-coding</td>
      <td>ACTA2</td>
      <td>actin alpha 2, smooth muscle</td>
      <td>O</td>
      <td>actin, aortic smooth muscle|actin, alpha 2, sm...</td>
      <td>20210307</td>
      <td>-</td>
    </tr>
    <tr>
      <th>83</th>
      <td>9606</td>
      <td>101</td>
      <td>ADAM8</td>
      <td>-</td>
      <td>CD156|CD156a|MS2</td>
      <td>MIM:602267|HGNC:HGNC:215|Ensembl:ENSG00000151651</td>
      <td>10</td>
      <td>10q26.3</td>
      <td>ADAM metallopeptidase domain 8</td>
      <td>protein-coding</td>
      <td>ADAM8</td>
      <td>ADAM metallopeptidase domain 8</td>
      <td>O</td>
      <td>disintegrin and metalloproteinase domain-conta...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>87</th>
      <td>9606</td>
      <td>105</td>
      <td>ADARB2</td>
      <td>-</td>
      <td>ADAR3|RED2</td>
      <td>MIM:602065|HGNC:HGNC:227|Ensembl:ENSG00000185736</td>
      <td>10</td>
      <td>10p15.3</td>
      <td>adenosine deaminase RNA specific B2 (inactive)</td>
      <td>protein-coding</td>
      <td>ADARB2</td>
      <td>adenosine deaminase RNA specific B2 (inactive)</td>
      <td>O</td>
      <td>double-stranded RNA-specific editase B2|RED2 h...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>101</th>
      <td>9606</td>
      <td>120</td>
      <td>ADD3</td>
      <td>-</td>
      <td>ADDL|CPSQ3</td>
      <td>MIM:601568|HGNC:HGNC:245|Ensembl:ENSG00000148700</td>
      <td>10</td>
      <td>10q25.1-q25.2</td>
      <td>adducin 3</td>
      <td>protein-coding</td>
      <td>ADD3</td>
      <td>adducin 3</td>
      <td>O</td>
      <td>gamma-adducin|adducin 3 (gamma)|adducin-like p...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>61081</th>
      <td>9606</td>
      <td>116216122</td>
      <td>LOC116216122</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>10</td>
      <td>10q</td>
      <td>CRISPRi-validated cis-regulatory element chr10...</td>
      <td>biological-region</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20210302</td>
      <td>regulatory:transcriptional_cis_regulatory_region</td>
    </tr>
    <tr>
      <th>61082</th>
      <td>9606</td>
      <td>116216123</td>
      <td>LOC116216123</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>10</td>
      <td>10q</td>
      <td>CRISPRi-validated cis-regulatory element chr10...</td>
      <td>biological-region</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20210302</td>
      <td>regulatory:transcriptional_cis_regulatory_region</td>
    </tr>
    <tr>
      <th>61472</th>
      <td>9606</td>
      <td>118568810</td>
      <td>SUV39H2-DT</td>
      <td>-</td>
      <td>-</td>
      <td>HGNC:HGNC:55188</td>
      <td>10</td>
      <td>10p13</td>
      <td>SUV39H2 divergent transcript</td>
      <td>ncRNA</td>
      <td>SUV39H2-DT</td>
      <td>SUV39H2 divergent transcript</td>
      <td>O</td>
      <td>-</td>
      <td>20201213</td>
      <td>-</td>
    </tr>
    <tr>
      <th>61487</th>
      <td>9606</td>
      <td>118568825</td>
      <td>CSGALNACT2-DT</td>
      <td>-</td>
      <td>-</td>
      <td>HGNC:HGNC:55174</td>
      <td>10</td>
      <td>10q11.21</td>
      <td>CSGALNACT2 divergent transcript</td>
      <td>ncRNA</td>
      <td>CSGALNACT2-DT</td>
      <td>CSGALNACT2 divergent transcript</td>
      <td>O</td>
      <td>-</td>
      <td>20201213</td>
      <td>-</td>
    </tr>
    <tr>
      <th>61514</th>
      <td>9606</td>
      <td>118732302</td>
      <td>CCNY-AS1</td>
      <td>-</td>
      <td>-</td>
      <td>HGNC:HGNC:55252</td>
      <td>10</td>
      <td>10p11.21</td>
      <td>CCNY antisense RNA 1</td>
      <td>ncRNA</td>
      <td>CCNY-AS1</td>
      <td>CCNY antisense RNA 1</td>
      <td>O</td>
      <td>-</td>
      <td>20201213</td>
      <td>-</td>
    </tr>
  </tbody>
</table>
<p>2462 rows × 16 columns</p>
</div>




```python
df[df['chromosome'] == '10']['Symbol']
```




    30              ACADSB
    49               ACTA2
    83               ADAM8
    87              ADARB2
    101               ADD3
                 ...      
    61081     LOC116216122
    61082     LOC116216123
    61472       SUV39H2-DT
    61487    CSGALNACT2-DT
    61514         CCNY-AS1
    Name: Symbol, Length: 2462, dtype: object




```python
df['type_of_gene'].unique()
```




    array(['protein-coding', 'pseudo', 'other', 'unknown', 'ncRNA', 'tRNA',
           'rRNA', 'scRNA', 'snoRNA', 'snRNA', 'biological-region'],
          dtype=object)




```python
df['type_of_gene'].value_counts()
```




    protein-coding       19697
    ncRNA                17498
    pseudo               16558
    biological-region     4466
    unknown               1385
    other                  840
    tRNA                   595
    snoRNA                 541
    snRNA                   71
    rRNA                    63
    scRNA                    4
    Name: type_of_gene, dtype: int64




```python
df['chromosome'] == '10'
```




    0        False
    1        False
    2        False
    3        False
    4        False
             ...  
    61713    False
    61714    False
    61715    False
    61716    False
    61717    False
    Name: chromosome, Length: 61718, dtype: bool




```python
df['type_of_gene'] == 'protein-coding'
```




    0         True
    1         True
    2        False
    3         True
    4         True
             ...  
    61713    False
    61714    False
    61715    False
    61716     True
    61717    False
    Name: type_of_gene, Length: 61718, dtype: bool




```python
df[(df['chromosome'] == '10') & (df['type_of_gene'] == 'protein-coding')]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>30</th>
      <td>9606</td>
      <td>36</td>
      <td>ACADSB</td>
      <td>-</td>
      <td>2-MEBCAD|ACAD7|SBCAD</td>
      <td>MIM:600301|HGNC:HGNC:91|Ensembl:ENSG00000196177</td>
      <td>10</td>
      <td>10q26.13</td>
      <td>acyl-CoA dehydrogenase short/branched chain</td>
      <td>protein-coding</td>
      <td>ACADSB</td>
      <td>acyl-CoA dehydrogenase short/branched chain</td>
      <td>O</td>
      <td>short/branched chain specific acyl-CoA dehydro...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>49</th>
      <td>9606</td>
      <td>59</td>
      <td>ACTA2</td>
      <td>-</td>
      <td>ACTSA</td>
      <td>MIM:102620|HGNC:HGNC:130|Ensembl:ENSG00000107796</td>
      <td>10</td>
      <td>10q23.31</td>
      <td>actin alpha 2, smooth muscle</td>
      <td>protein-coding</td>
      <td>ACTA2</td>
      <td>actin alpha 2, smooth muscle</td>
      <td>O</td>
      <td>actin, aortic smooth muscle|actin, alpha 2, sm...</td>
      <td>20210307</td>
      <td>-</td>
    </tr>
    <tr>
      <th>83</th>
      <td>9606</td>
      <td>101</td>
      <td>ADAM8</td>
      <td>-</td>
      <td>CD156|CD156a|MS2</td>
      <td>MIM:602267|HGNC:HGNC:215|Ensembl:ENSG00000151651</td>
      <td>10</td>
      <td>10q26.3</td>
      <td>ADAM metallopeptidase domain 8</td>
      <td>protein-coding</td>
      <td>ADAM8</td>
      <td>ADAM metallopeptidase domain 8</td>
      <td>O</td>
      <td>disintegrin and metalloproteinase domain-conta...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>87</th>
      <td>9606</td>
      <td>105</td>
      <td>ADARB2</td>
      <td>-</td>
      <td>ADAR3|RED2</td>
      <td>MIM:602065|HGNC:HGNC:227|Ensembl:ENSG00000185736</td>
      <td>10</td>
      <td>10p15.3</td>
      <td>adenosine deaminase RNA specific B2 (inactive)</td>
      <td>protein-coding</td>
      <td>ADARB2</td>
      <td>adenosine deaminase RNA specific B2 (inactive)</td>
      <td>O</td>
      <td>double-stranded RNA-specific editase B2|RED2 h...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>101</th>
      <td>9606</td>
      <td>120</td>
      <td>ADD3</td>
      <td>-</td>
      <td>ADDL|CPSQ3</td>
      <td>MIM:601568|HGNC:HGNC:245|Ensembl:ENSG00000148700</td>
      <td>10</td>
      <td>10q25.1-q25.2</td>
      <td>adducin 3</td>
      <td>protein-coding</td>
      <td>ADD3</td>
      <td>adducin 3</td>
      <td>O</td>
      <td>gamma-adducin|adducin 3 (gamma)|adducin-like p...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>53349</th>
      <td>9606</td>
      <td>107983989</td>
      <td>LOC107983989</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>10</td>
      <td>10p15.3</td>
      <td>uncharacterized LOC107983989</td>
      <td>protein-coding</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>uncharacterized protein LOC107983989</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>53461</th>
      <td>9606</td>
      <td>107984189</td>
      <td>LOC107984189</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>10</td>
      <td>10q11.21</td>
      <td>uncharacterized protein C10orf142-like</td>
      <td>protein-coding</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>uncharacterized protein C10orf142-like</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>53474</th>
      <td>9606</td>
      <td>107984203</td>
      <td>LOC107984203</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>10</td>
      <td>10p14</td>
      <td>endogenous retrovirus group K member 6 Env pol...</td>
      <td>protein-coding</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>endogenous retrovirus group K member 6 Env pol...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>53527</th>
      <td>9606</td>
      <td>107984264</td>
      <td>LOC107984264</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>10</td>
      <td>10q24.32</td>
      <td>transmembrane protein 108-like</td>
      <td>protein-coding</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>transmembrane protein 108-like</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>59468</th>
      <td>9606</td>
      <td>112577516</td>
      <td>LOC112577516</td>
      <td>-</td>
      <td>-</td>
      <td>Ensembl:ENSG00000286135</td>
      <td>10</td>
      <td>10q26.13</td>
      <td>carbohydrate-binding protein AQN-1-like</td>
      <td>protein-coding</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>carbohydrate-binding protein AQN-1-like</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
  </tbody>
</table>
<p>722 rows × 16 columns</p>
</div>




```python
df[(df['chromosome'] == '10') & (df['type_of_gene'] == 'protein-coding')]['Symbol']
```




    30             ACADSB
    49              ACTA2
    83              ADAM8
    87             ADARB2
    101              ADD3
                 ...     
    53349    LOC107983989
    53461    LOC107984189
    53474    LOC107984203
    53527    LOC107984264
    59468    LOC112577516
    Name: Symbol, Length: 722, dtype: object




```python
df[df['chromosome'] == '10']['type_of_gene'].value_counts()
```




    ncRNA                814
    protein-coding       722
    pseudo               648
    biological-region    202
    unknown               46
    snoRNA                14
    other                 13
    tRNA                   3
    Name: type_of_gene, dtype: int64




```python
df2 = df[(df['chromosome'] == '10') & (df['type_of_gene'] == 'tRNA')]
```


```python
df2
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>31048</th>
      <td>9606</td>
      <td>100189083</td>
      <td>TRN-GTT2-3</td>
      <td>-</td>
      <td>TRNAN11</td>
      <td>HGNC:HGNC:34643</td>
      <td>10</td>
      <td>10p12.31</td>
      <td>tRNA-Asn (anticodon GTT) 2-3</td>
      <td>tRNA</td>
      <td>TRN-GTT2-3</td>
      <td>tRNA-Asn (anticodon GTT) 2-3</td>
      <td>O</td>
      <td>tRNA-Asn (GTT) 2-3|transfer RNA asparagine 11 ...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>31239</th>
      <td>9606</td>
      <td>100189279</td>
      <td>TRS-TGA1-1</td>
      <td>-</td>
      <td>TRNAS21</td>
      <td>HGNC:HGNC:34845</td>
      <td>10</td>
      <td>10q21.3</td>
      <td>tRNA-Ser (anticodon TGA) 1-1</td>
      <td>tRNA</td>
      <td>TRS-TGA1-1</td>
      <td>tRNA-Ser (anticodon TGA) 1-1</td>
      <td>O</td>
      <td>tRNA-Ser-TGA-1-1|transfer RNA serine 21 (antic...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>31301</th>
      <td>9606</td>
      <td>100189342</td>
      <td>TRV-TAC3-1</td>
      <td>-</td>
      <td>TRNAV26</td>
      <td>HGNC:HGNC:34910</td>
      <td>10</td>
      <td>10p15.1</td>
      <td>tRNA-Val (anticodon TAC) 3-1</td>
      <td>tRNA</td>
      <td>TRV-TAC3-1</td>
      <td>tRNA-Val (anticodon TAC) 3-1</td>
      <td>O</td>
      <td>tRNA-Val-TAC-3-1|transfer RNA valine 26 (antic...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
  </tbody>
</table>
</div>




```python
df[(df['chromosome'] == '10') & (df['type_of_gene'] == 'protein-coding')]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>30</th>
      <td>9606</td>
      <td>36</td>
      <td>ACADSB</td>
      <td>-</td>
      <td>2-MEBCAD|ACAD7|SBCAD</td>
      <td>MIM:600301|HGNC:HGNC:91|Ensembl:ENSG00000196177</td>
      <td>10</td>
      <td>10q26.13</td>
      <td>acyl-CoA dehydrogenase short/branched chain</td>
      <td>protein-coding</td>
      <td>ACADSB</td>
      <td>acyl-CoA dehydrogenase short/branched chain</td>
      <td>O</td>
      <td>short/branched chain specific acyl-CoA dehydro...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>49</th>
      <td>9606</td>
      <td>59</td>
      <td>ACTA2</td>
      <td>-</td>
      <td>ACTSA</td>
      <td>MIM:102620|HGNC:HGNC:130|Ensembl:ENSG00000107796</td>
      <td>10</td>
      <td>10q23.31</td>
      <td>actin alpha 2, smooth muscle</td>
      <td>protein-coding</td>
      <td>ACTA2</td>
      <td>actin alpha 2, smooth muscle</td>
      <td>O</td>
      <td>actin, aortic smooth muscle|actin, alpha 2, sm...</td>
      <td>20210307</td>
      <td>-</td>
    </tr>
    <tr>
      <th>83</th>
      <td>9606</td>
      <td>101</td>
      <td>ADAM8</td>
      <td>-</td>
      <td>CD156|CD156a|MS2</td>
      <td>MIM:602267|HGNC:HGNC:215|Ensembl:ENSG00000151651</td>
      <td>10</td>
      <td>10q26.3</td>
      <td>ADAM metallopeptidase domain 8</td>
      <td>protein-coding</td>
      <td>ADAM8</td>
      <td>ADAM metallopeptidase domain 8</td>
      <td>O</td>
      <td>disintegrin and metalloproteinase domain-conta...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>87</th>
      <td>9606</td>
      <td>105</td>
      <td>ADARB2</td>
      <td>-</td>
      <td>ADAR3|RED2</td>
      <td>MIM:602065|HGNC:HGNC:227|Ensembl:ENSG00000185736</td>
      <td>10</td>
      <td>10p15.3</td>
      <td>adenosine deaminase RNA specific B2 (inactive)</td>
      <td>protein-coding</td>
      <td>ADARB2</td>
      <td>adenosine deaminase RNA specific B2 (inactive)</td>
      <td>O</td>
      <td>double-stranded RNA-specific editase B2|RED2 h...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>101</th>
      <td>9606</td>
      <td>120</td>
      <td>ADD3</td>
      <td>-</td>
      <td>ADDL|CPSQ3</td>
      <td>MIM:601568|HGNC:HGNC:245|Ensembl:ENSG00000148700</td>
      <td>10</td>
      <td>10q25.1-q25.2</td>
      <td>adducin 3</td>
      <td>protein-coding</td>
      <td>ADD3</td>
      <td>adducin 3</td>
      <td>O</td>
      <td>gamma-adducin|adducin 3 (gamma)|adducin-like p...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>53349</th>
      <td>9606</td>
      <td>107983989</td>
      <td>LOC107983989</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>10</td>
      <td>10p15.3</td>
      <td>uncharacterized LOC107983989</td>
      <td>protein-coding</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>uncharacterized protein LOC107983989</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>53461</th>
      <td>9606</td>
      <td>107984189</td>
      <td>LOC107984189</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>10</td>
      <td>10q11.21</td>
      <td>uncharacterized protein C10orf142-like</td>
      <td>protein-coding</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>uncharacterized protein C10orf142-like</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>53474</th>
      <td>9606</td>
      <td>107984203</td>
      <td>LOC107984203</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>10</td>
      <td>10p14</td>
      <td>endogenous retrovirus group K member 6 Env pol...</td>
      <td>protein-coding</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>endogenous retrovirus group K member 6 Env pol...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>53527</th>
      <td>9606</td>
      <td>107984264</td>
      <td>LOC107984264</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>10</td>
      <td>10q24.32</td>
      <td>transmembrane protein 108-like</td>
      <td>protein-coding</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>transmembrane protein 108-like</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>59468</th>
      <td>9606</td>
      <td>112577516</td>
      <td>LOC112577516</td>
      <td>-</td>
      <td>-</td>
      <td>Ensembl:ENSG00000286135</td>
      <td>10</td>
      <td>10q26.13</td>
      <td>carbohydrate-binding protein AQN-1-like</td>
      <td>protein-coding</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>carbohydrate-binding protein AQN-1-like</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
  </tbody>
</table>
<p>722 rows × 16 columns</p>
</div>




```python
df['description'].str.contains('membrane')
```




    False    60861
    True       857
    Name: description, dtype: int64




```python
df[(df['chromosome'] == '10') & (df['type_of_gene'] == 'protein-coding') & df['description'].str.contains('membrane')]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>9703</th>
      <td>9606</td>
      <td>25805</td>
      <td>BAMBI</td>
      <td>-</td>
      <td>NMA</td>
      <td>MIM:604444|HGNC:HGNC:30251|Ensembl:ENSG0000009...</td>
      <td>10</td>
      <td>10p12.1</td>
      <td>BMP and activin membrane bound inhibitor</td>
      <td>protein-coding</td>
      <td>BAMBI</td>
      <td>BMP and activin membrane bound inhibitor</td>
      <td>O</td>
      <td>BMP and activin membrane-bound inhibitor homol...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>9917</th>
      <td>9606</td>
      <td>26103</td>
      <td>LRIT1</td>
      <td>-</td>
      <td>FIGLER9|LRRC21|PAL</td>
      <td>MIM:616103|HGNC:HGNC:23404|Ensembl:ENSG0000014...</td>
      <td>10</td>
      <td>10q23.1</td>
      <td>leucine rich repeat, Ig-like and transmembrane...</td>
      <td>protein-coding</td>
      <td>LRIT1</td>
      <td>leucine rich repeat, Ig-like and transmembrane...</td>
      <td>O</td>
      <td>leucine-rich repeat, immunoglobulin-like domai...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>10303</th>
      <td>9606</td>
      <td>27069</td>
      <td>GHITM</td>
      <td>-</td>
      <td>DERP2|HSPC282|MICS1|My021|PTD010|TMBIM5</td>
      <td>MIM:619205|HGNC:HGNC:17281|Ensembl:ENSG0000016...</td>
      <td>10</td>
      <td>10q23.1</td>
      <td>growth hormone inducible transmembrane protein</td>
      <td>protein-coding</td>
      <td>GHITM</td>
      <td>growth hormone inducible transmembrane protein</td>
      <td>O</td>
      <td>growth hormone-inducible transmembrane protein...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>12269</th>
      <td>9606</td>
      <td>54708</td>
      <td>MARCHF5</td>
      <td>-</td>
      <td>MARCH-V|MARCH5|MITOL|RNF153</td>
      <td>MIM:610637|HGNC:HGNC:26025|Ensembl:ENSG0000019...</td>
      <td>10</td>
      <td>10q23.32-q23.33</td>
      <td>membrane associated ring-CH-type finger 5</td>
      <td>protein-coding</td>
      <td>MARCHF5</td>
      <td>membrane associated ring-CH-type finger 5</td>
      <td>O</td>
      <td>E3 ubiquitin-protein ligase MARCHF5|E3 ubiquit...</td>
      <td>20210307</td>
      <td>-</td>
    </tr>
    <tr>
      <th>13327</th>
      <td>9606</td>
      <td>56889</td>
      <td>TM9SF3</td>
      <td>-</td>
      <td>EP70-P-iso|SMBP</td>
      <td>MIM:616872|HGNC:HGNC:21529|Ensembl:ENSG0000007...</td>
      <td>10</td>
      <td>10q24.1</td>
      <td>transmembrane 9 superfamily member 3</td>
      <td>protein-coding</td>
      <td>TM9SF3</td>
      <td>transmembrane 9 superfamily member 3</td>
      <td>O</td>
      <td>transmembrane 9 superfamily member 3|SM-11044-...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>15125</th>
      <td>9606</td>
      <td>80195</td>
      <td>TMEM254</td>
      <td>-</td>
      <td>C10orf57|bA369J21.6</td>
      <td>HGNC:HGNC:25804|Ensembl:ENSG00000133678</td>
      <td>10</td>
      <td>10q22.3</td>
      <td>transmembrane protein 254</td>
      <td>protein-coding</td>
      <td>TMEM254</td>
      <td>transmembrane protein 254</td>
      <td>O</td>
      <td>transmembrane protein 254|transmembrane protei...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>16177</th>
      <td>9606</td>
      <td>84833</td>
      <td>ATP5MK</td>
      <td>-</td>
      <td>AGP|ATP5MD|DAPIT|HCVFTP2|MC5DN6|USMG5|bA792D24.4</td>
      <td>MIM:615204|HGNC:HGNC:30889|Ensembl:ENSG0000017...</td>
      <td>10</td>
      <td>10q24.33</td>
      <td>ATP synthase membrane subunit k</td>
      <td>protein-coding</td>
      <td>ATP5MK</td>
      <td>ATP synthase membrane subunit k</td>
      <td>O</td>
      <td>ATP synthase membrane subunit DAPIT, mitochond...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>18391</th>
      <td>9606</td>
      <td>143098</td>
      <td>MPP7</td>
      <td>-</td>
      <td>-</td>
      <td>MIM:610973|HGNC:HGNC:26542|Ensembl:ENSG0000015...</td>
      <td>10</td>
      <td>10p12.1</td>
      <td>membrane palmitoylated protein 7</td>
      <td>protein-coding</td>
      <td>MPP7</td>
      <td>membrane palmitoylated protein 7</td>
      <td>O</td>
      <td>MAGUK p55 subfamily member 7|membrane protein,...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>19403</th>
      <td>9606</td>
      <td>170371</td>
      <td>TMEM273</td>
      <td>-</td>
      <td>C10orf128</td>
      <td>HGNC:HGNC:27274|Ensembl:ENSG00000204161</td>
      <td>10</td>
      <td>10q11.23</td>
      <td>transmembrane protein 273</td>
      <td>protein-coding</td>
      <td>TMEM273</td>
      <td>transmembrane protein 273</td>
      <td>O</td>
      <td>transmembrane protein 273</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>19585</th>
      <td>9606</td>
      <td>196740</td>
      <td>VSTM4</td>
      <td>-</td>
      <td>C10orf72</td>
      <td>HGNC:HGNC:26470|Ensembl:ENSG00000165633</td>
      <td>10</td>
      <td>10q11.23</td>
      <td>V-set and transmembrane domain containing 4</td>
      <td>protein-coding</td>
      <td>VSTM4</td>
      <td>V-set and transmembrane domain containing 4</td>
      <td>O</td>
      <td>V-set and transmembrane domain-containing prot...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>19863</th>
      <td>9606</td>
      <td>219623</td>
      <td>TMEM26</td>
      <td>-</td>
      <td>-</td>
      <td>MIM:617803|HGNC:HGNC:28550|Ensembl:ENSG0000019...</td>
      <td>10</td>
      <td>10q21.2</td>
      <td>transmembrane protein 26</td>
      <td>protein-coding</td>
      <td>TMEM26</td>
      <td>transmembrane protein 26</td>
      <td>O</td>
      <td>transmembrane protein 26</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>19958</th>
      <td>9606</td>
      <td>220972</td>
      <td>MARCHF8</td>
      <td>-</td>
      <td>CMIR|MARCH-VIII|MARCH8|MIR|RNF178|c-MIR</td>
      <td>MIM:613335|HGNC:HGNC:23356|Ensembl:ENSG0000016...</td>
      <td>10</td>
      <td>10q11.21-q11.22</td>
      <td>membrane associated ring-CH-type finger 8</td>
      <td>protein-coding</td>
      <td>MARCHF8</td>
      <td>membrane associated ring-CH-type finger 8</td>
      <td>O</td>
      <td>E3 ubiquitin-protein ligase MARCHF8|E3 ubiquit...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>21794</th>
      <td>9606</td>
      <td>340745</td>
      <td>LRIT2</td>
      <td>-</td>
      <td>LRRC22</td>
      <td>HGNC:HGNC:23443|Ensembl:ENSG00000204033</td>
      <td>10</td>
      <td>10q23.1</td>
      <td>leucine rich repeat, Ig-like and transmembrane...</td>
      <td>protein-coding</td>
      <td>LRIT2</td>
      <td>leucine rich repeat, Ig-like and transmembrane...</td>
      <td>O</td>
      <td>leucine-rich repeat, immunoglobulin-like domai...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>22098</th>
      <td>9606</td>
      <td>347731</td>
      <td>LRRTM3</td>
      <td>-</td>
      <td>-</td>
      <td>MIM:610869|HGNC:HGNC:19410|Ensembl:ENSG0000019...</td>
      <td>10</td>
      <td>10q21.3</td>
      <td>leucine rich repeat transmembrane neuronal 3</td>
      <td>protein-coding</td>
      <td>LRRTM3</td>
      <td>leucine rich repeat transmembrane neuronal 3</td>
      <td>O</td>
      <td>leucine-rich repeat transmembrane neuronal pro...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>25984</th>
      <td>9606</td>
      <td>643236</td>
      <td>TMEM72</td>
      <td>-</td>
      <td>C10orf127|KSP37</td>
      <td>HGNC:HGNC:31658|Ensembl:ENSG00000187783</td>
      <td>10</td>
      <td>10q11.21</td>
      <td>transmembrane protein 72</td>
      <td>protein-coding</td>
      <td>TMEM72</td>
      <td>transmembrane protein 72</td>
      <td>O</td>
      <td>transmembrane protein 72|kidney-specific secre...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>27176</th>
      <td>9606</td>
      <td>653567</td>
      <td>TMEM236</td>
      <td>-</td>
      <td>FAM23A|FAM23B|bA162I21.2|bA16O1.2</td>
      <td>HGNC:HGNC:23473|Ensembl:ENSG00000148483</td>
      <td>10</td>
      <td>10p12.33</td>
      <td>transmembrane protein 236</td>
      <td>protein-coding</td>
      <td>TMEM236</td>
      <td>transmembrane protein 236</td>
      <td>O</td>
      <td>transmembrane protein 236|family with sequence...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>32675</th>
      <td>9606</td>
      <td>100287932</td>
      <td>TIMM23</td>
      <td>-</td>
      <td>TIM23</td>
      <td>MIM:605034|HGNC:HGNC:17312|Ensembl:ENSG0000026...</td>
      <td>10</td>
      <td>10q11.22</td>
      <td>translocase of inner mitochondrial membrane 23</td>
      <td>protein-coding</td>
      <td>TIMM23</td>
      <td>translocase of inner mitochondrial membrane 23</td>
      <td>O</td>
      <td>mitochondrial import inner membrane translocas...</td>
      <td>20210307</td>
      <td>-</td>
    </tr>
    <tr>
      <th>37136</th>
      <td>9606</td>
      <td>100652748</td>
      <td>TIMM23B</td>
      <td>-</td>
      <td>-</td>
      <td>HGNC:HGNC:23581|Ensembl:ENSG00000204152</td>
      <td>10</td>
      <td>10q11.23</td>
      <td>translocase of inner mitochondrial membrane 23...</td>
      <td>protein-coding</td>
      <td>TIMM23B</td>
      <td>translocase of inner mitochondrial membrane 23...</td>
      <td>O</td>
      <td>mitochondrial import inner membrane translocas...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>53527</th>
      <td>9606</td>
      <td>107984264</td>
      <td>LOC107984264</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>10</td>
      <td>10q24.32</td>
      <td>transmembrane protein 108-like</td>
      <td>protein-coding</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>transmembrane protein 108-like</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
  </tbody>
</table>
</div>




```python
df[(df['chromosome'] == '10') & (df['type_of_gene'] == 'protein-coding') & df['description'].str.contains('membrane', case=False)]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>9703</th>
      <td>9606</td>
      <td>25805</td>
      <td>BAMBI</td>
      <td>-</td>
      <td>NMA</td>
      <td>MIM:604444|HGNC:HGNC:30251|Ensembl:ENSG0000009...</td>
      <td>10</td>
      <td>10p12.1</td>
      <td>BMP and activin membrane bound inhibitor</td>
      <td>protein-coding</td>
      <td>BAMBI</td>
      <td>BMP and activin membrane bound inhibitor</td>
      <td>O</td>
      <td>BMP and activin membrane-bound inhibitor homol...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>9917</th>
      <td>9606</td>
      <td>26103</td>
      <td>LRIT1</td>
      <td>-</td>
      <td>FIGLER9|LRRC21|PAL</td>
      <td>MIM:616103|HGNC:HGNC:23404|Ensembl:ENSG0000014...</td>
      <td>10</td>
      <td>10q23.1</td>
      <td>leucine rich repeat, Ig-like and transmembrane...</td>
      <td>protein-coding</td>
      <td>LRIT1</td>
      <td>leucine rich repeat, Ig-like and transmembrane...</td>
      <td>O</td>
      <td>leucine-rich repeat, immunoglobulin-like domai...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>10303</th>
      <td>9606</td>
      <td>27069</td>
      <td>GHITM</td>
      <td>-</td>
      <td>DERP2|HSPC282|MICS1|My021|PTD010|TMBIM5</td>
      <td>MIM:619205|HGNC:HGNC:17281|Ensembl:ENSG0000016...</td>
      <td>10</td>
      <td>10q23.1</td>
      <td>growth hormone inducible transmembrane protein</td>
      <td>protein-coding</td>
      <td>GHITM</td>
      <td>growth hormone inducible transmembrane protein</td>
      <td>O</td>
      <td>growth hormone-inducible transmembrane protein...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>12269</th>
      <td>9606</td>
      <td>54708</td>
      <td>MARCHF5</td>
      <td>-</td>
      <td>MARCH-V|MARCH5|MITOL|RNF153</td>
      <td>MIM:610637|HGNC:HGNC:26025|Ensembl:ENSG0000019...</td>
      <td>10</td>
      <td>10q23.32-q23.33</td>
      <td>membrane associated ring-CH-type finger 5</td>
      <td>protein-coding</td>
      <td>MARCHF5</td>
      <td>membrane associated ring-CH-type finger 5</td>
      <td>O</td>
      <td>E3 ubiquitin-protein ligase MARCHF5|E3 ubiquit...</td>
      <td>20210307</td>
      <td>-</td>
    </tr>
    <tr>
      <th>13327</th>
      <td>9606</td>
      <td>56889</td>
      <td>TM9SF3</td>
      <td>-</td>
      <td>EP70-P-iso|SMBP</td>
      <td>MIM:616872|HGNC:HGNC:21529|Ensembl:ENSG0000007...</td>
      <td>10</td>
      <td>10q24.1</td>
      <td>transmembrane 9 superfamily member 3</td>
      <td>protein-coding</td>
      <td>TM9SF3</td>
      <td>transmembrane 9 superfamily member 3</td>
      <td>O</td>
      <td>transmembrane 9 superfamily member 3|SM-11044-...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>15125</th>
      <td>9606</td>
      <td>80195</td>
      <td>TMEM254</td>
      <td>-</td>
      <td>C10orf57|bA369J21.6</td>
      <td>HGNC:HGNC:25804|Ensembl:ENSG00000133678</td>
      <td>10</td>
      <td>10q22.3</td>
      <td>transmembrane protein 254</td>
      <td>protein-coding</td>
      <td>TMEM254</td>
      <td>transmembrane protein 254</td>
      <td>O</td>
      <td>transmembrane protein 254|transmembrane protei...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>16177</th>
      <td>9606</td>
      <td>84833</td>
      <td>ATP5MK</td>
      <td>-</td>
      <td>AGP|ATP5MD|DAPIT|HCVFTP2|MC5DN6|USMG5|bA792D24.4</td>
      <td>MIM:615204|HGNC:HGNC:30889|Ensembl:ENSG0000017...</td>
      <td>10</td>
      <td>10q24.33</td>
      <td>ATP synthase membrane subunit k</td>
      <td>protein-coding</td>
      <td>ATP5MK</td>
      <td>ATP synthase membrane subunit k</td>
      <td>O</td>
      <td>ATP synthase membrane subunit DAPIT, mitochond...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>18391</th>
      <td>9606</td>
      <td>143098</td>
      <td>MPP7</td>
      <td>-</td>
      <td>-</td>
      <td>MIM:610973|HGNC:HGNC:26542|Ensembl:ENSG0000015...</td>
      <td>10</td>
      <td>10p12.1</td>
      <td>membrane palmitoylated protein 7</td>
      <td>protein-coding</td>
      <td>MPP7</td>
      <td>membrane palmitoylated protein 7</td>
      <td>O</td>
      <td>MAGUK p55 subfamily member 7|membrane protein,...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>19403</th>
      <td>9606</td>
      <td>170371</td>
      <td>TMEM273</td>
      <td>-</td>
      <td>C10orf128</td>
      <td>HGNC:HGNC:27274|Ensembl:ENSG00000204161</td>
      <td>10</td>
      <td>10q11.23</td>
      <td>transmembrane protein 273</td>
      <td>protein-coding</td>
      <td>TMEM273</td>
      <td>transmembrane protein 273</td>
      <td>O</td>
      <td>transmembrane protein 273</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>19585</th>
      <td>9606</td>
      <td>196740</td>
      <td>VSTM4</td>
      <td>-</td>
      <td>C10orf72</td>
      <td>HGNC:HGNC:26470|Ensembl:ENSG00000165633</td>
      <td>10</td>
      <td>10q11.23</td>
      <td>V-set and transmembrane domain containing 4</td>
      <td>protein-coding</td>
      <td>VSTM4</td>
      <td>V-set and transmembrane domain containing 4</td>
      <td>O</td>
      <td>V-set and transmembrane domain-containing prot...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>19863</th>
      <td>9606</td>
      <td>219623</td>
      <td>TMEM26</td>
      <td>-</td>
      <td>-</td>
      <td>MIM:617803|HGNC:HGNC:28550|Ensembl:ENSG0000019...</td>
      <td>10</td>
      <td>10q21.2</td>
      <td>transmembrane protein 26</td>
      <td>protein-coding</td>
      <td>TMEM26</td>
      <td>transmembrane protein 26</td>
      <td>O</td>
      <td>transmembrane protein 26</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>19958</th>
      <td>9606</td>
      <td>220972</td>
      <td>MARCHF8</td>
      <td>-</td>
      <td>CMIR|MARCH-VIII|MARCH8|MIR|RNF178|c-MIR</td>
      <td>MIM:613335|HGNC:HGNC:23356|Ensembl:ENSG0000016...</td>
      <td>10</td>
      <td>10q11.21-q11.22</td>
      <td>membrane associated ring-CH-type finger 8</td>
      <td>protein-coding</td>
      <td>MARCHF8</td>
      <td>membrane associated ring-CH-type finger 8</td>
      <td>O</td>
      <td>E3 ubiquitin-protein ligase MARCHF8|E3 ubiquit...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>21794</th>
      <td>9606</td>
      <td>340745</td>
      <td>LRIT2</td>
      <td>-</td>
      <td>LRRC22</td>
      <td>HGNC:HGNC:23443|Ensembl:ENSG00000204033</td>
      <td>10</td>
      <td>10q23.1</td>
      <td>leucine rich repeat, Ig-like and transmembrane...</td>
      <td>protein-coding</td>
      <td>LRIT2</td>
      <td>leucine rich repeat, Ig-like and transmembrane...</td>
      <td>O</td>
      <td>leucine-rich repeat, immunoglobulin-like domai...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>22098</th>
      <td>9606</td>
      <td>347731</td>
      <td>LRRTM3</td>
      <td>-</td>
      <td>-</td>
      <td>MIM:610869|HGNC:HGNC:19410|Ensembl:ENSG0000019...</td>
      <td>10</td>
      <td>10q21.3</td>
      <td>leucine rich repeat transmembrane neuronal 3</td>
      <td>protein-coding</td>
      <td>LRRTM3</td>
      <td>leucine rich repeat transmembrane neuronal 3</td>
      <td>O</td>
      <td>leucine-rich repeat transmembrane neuronal pro...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>25984</th>
      <td>9606</td>
      <td>643236</td>
      <td>TMEM72</td>
      <td>-</td>
      <td>C10orf127|KSP37</td>
      <td>HGNC:HGNC:31658|Ensembl:ENSG00000187783</td>
      <td>10</td>
      <td>10q11.21</td>
      <td>transmembrane protein 72</td>
      <td>protein-coding</td>
      <td>TMEM72</td>
      <td>transmembrane protein 72</td>
      <td>O</td>
      <td>transmembrane protein 72|kidney-specific secre...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>27176</th>
      <td>9606</td>
      <td>653567</td>
      <td>TMEM236</td>
      <td>-</td>
      <td>FAM23A|FAM23B|bA162I21.2|bA16O1.2</td>
      <td>HGNC:HGNC:23473|Ensembl:ENSG00000148483</td>
      <td>10</td>
      <td>10p12.33</td>
      <td>transmembrane protein 236</td>
      <td>protein-coding</td>
      <td>TMEM236</td>
      <td>transmembrane protein 236</td>
      <td>O</td>
      <td>transmembrane protein 236|family with sequence...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>32675</th>
      <td>9606</td>
      <td>100287932</td>
      <td>TIMM23</td>
      <td>-</td>
      <td>TIM23</td>
      <td>MIM:605034|HGNC:HGNC:17312|Ensembl:ENSG0000026...</td>
      <td>10</td>
      <td>10q11.22</td>
      <td>translocase of inner mitochondrial membrane 23</td>
      <td>protein-coding</td>
      <td>TIMM23</td>
      <td>translocase of inner mitochondrial membrane 23</td>
      <td>O</td>
      <td>mitochondrial import inner membrane translocas...</td>
      <td>20210307</td>
      <td>-</td>
    </tr>
    <tr>
      <th>37136</th>
      <td>9606</td>
      <td>100652748</td>
      <td>TIMM23B</td>
      <td>-</td>
      <td>-</td>
      <td>HGNC:HGNC:23581|Ensembl:ENSG00000204152</td>
      <td>10</td>
      <td>10q11.23</td>
      <td>translocase of inner mitochondrial membrane 23...</td>
      <td>protein-coding</td>
      <td>TIMM23B</td>
      <td>translocase of inner mitochondrial membrane 23...</td>
      <td>O</td>
      <td>mitochondrial import inner membrane translocas...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>53527</th>
      <td>9606</td>
      <td>107984264</td>
      <td>LOC107984264</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>10</td>
      <td>10q24.32</td>
      <td>transmembrane protein 108-like</td>
      <td>protein-coding</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>transmembrane protein 108-like</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
  </tbody>
</table>
</div>




```python
df['chromosome'].value_counts().plot(kind='bar')
```




    <AxesSubplot:>




    
![png](output_29_1.png)
    



```python
df[(df['chromosome'] == '10') | (df['chromosome'] == '11') ]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>30</th>
      <td>9606</td>
      <td>36</td>
      <td>ACADSB</td>
      <td>-</td>
      <td>2-MEBCAD|ACAD7|SBCAD</td>
      <td>MIM:600301|HGNC:HGNC:91|Ensembl:ENSG00000196177</td>
      <td>10</td>
      <td>10q26.13</td>
      <td>acyl-CoA dehydrogenase short/branched chain</td>
      <td>protein-coding</td>
      <td>ACADSB</td>
      <td>acyl-CoA dehydrogenase short/branched chain</td>
      <td>O</td>
      <td>short/branched chain specific acyl-CoA dehydro...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>32</th>
      <td>9606</td>
      <td>38</td>
      <td>ACAT1</td>
      <td>-</td>
      <td>ACAT|MAT|T2|THIL</td>
      <td>MIM:607809|HGNC:HGNC:93|Ensembl:ENSG00000075239</td>
      <td>11</td>
      <td>11q22.3</td>
      <td>acetyl-CoA acetyltransferase 1</td>
      <td>protein-coding</td>
      <td>ACAT1</td>
      <td>acetyl-CoA acetyltransferase 1</td>
      <td>O</td>
      <td>acetyl-CoA acetyltransferase, mitochondrial|ac...</td>
      <td>20210307</td>
      <td>-</td>
    </tr>
    <tr>
      <th>44</th>
      <td>9606</td>
      <td>53</td>
      <td>ACP2</td>
      <td>-</td>
      <td>LAP</td>
      <td>MIM:171650|HGNC:HGNC:123|Ensembl:ENSG00000134575</td>
      <td>11</td>
      <td>11p11.2|11p12-p11</td>
      <td>acid phosphatase 2, lysosomal</td>
      <td>protein-coding</td>
      <td>ACP2</td>
      <td>acid phosphatase 2, lysosomal</td>
      <td>O</td>
      <td>lysosomal acid phosphatase</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>47</th>
      <td>9606</td>
      <td>56</td>
      <td>ACRV1</td>
      <td>-</td>
      <td>D11S4365|SP-10|SPACA2</td>
      <td>MIM:102525|HGNC:HGNC:127|Ensembl:ENSG00000134940</td>
      <td>11</td>
      <td>11q24.2</td>
      <td>acrosomal vesicle protein 1</td>
      <td>protein-coding</td>
      <td>ACRV1</td>
      <td>acrosomal vesicle protein 1</td>
      <td>O</td>
      <td>acrosomal protein SP-10|sperm protein 10</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>49</th>
      <td>9606</td>
      <td>59</td>
      <td>ACTA2</td>
      <td>-</td>
      <td>ACTSA</td>
      <td>MIM:102620|HGNC:HGNC:130|Ensembl:ENSG00000107796</td>
      <td>10</td>
      <td>10q23.31</td>
      <td>actin alpha 2, smooth muscle</td>
      <td>protein-coding</td>
      <td>ACTA2</td>
      <td>actin alpha 2, smooth muscle</td>
      <td>O</td>
      <td>actin, aortic smooth muscle|actin, alpha 2, sm...</td>
      <td>20210307</td>
      <td>-</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>61504</th>
      <td>9606</td>
      <td>118597841</td>
      <td>VPS11-DT</td>
      <td>-</td>
      <td>-</td>
      <td>HGNC:HGNC:55227</td>
      <td>11</td>
      <td>11q23.3</td>
      <td>VPS11 divergent transcript</td>
      <td>ncRNA</td>
      <td>VPS11-DT</td>
      <td>VPS11 divergent transcript</td>
      <td>O</td>
      <td>TCONS_00019777</td>
      <td>20201213</td>
      <td>-</td>
    </tr>
    <tr>
      <th>61514</th>
      <td>9606</td>
      <td>118732302</td>
      <td>CCNY-AS1</td>
      <td>-</td>
      <td>-</td>
      <td>HGNC:HGNC:55252</td>
      <td>10</td>
      <td>10p11.21</td>
      <td>CCNY antisense RNA 1</td>
      <td>ncRNA</td>
      <td>CCNY-AS1</td>
      <td>CCNY antisense RNA 1</td>
      <td>O</td>
      <td>-</td>
      <td>20201213</td>
      <td>-</td>
    </tr>
    <tr>
      <th>61519</th>
      <td>9606</td>
      <td>118827805</td>
      <td>SF1-DT</td>
      <td>-</td>
      <td>-</td>
      <td>HGNC:HGNC:55278</td>
      <td>11</td>
      <td>11q13.1</td>
      <td>SF1 divergent transcript</td>
      <td>ncRNA</td>
      <td>SF1-DT</td>
      <td>SF1 divergent transcript</td>
      <td>O</td>
      <td>-</td>
      <td>20201213</td>
      <td>-</td>
    </tr>
    <tr>
      <th>61624</th>
      <td>9606</td>
      <td>120356739</td>
      <td>LRRC51</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>11</td>
      <td>-</td>
      <td>leucine-rich repeat-containing protein 51</td>
      <td>protein-coding</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>leucine-rich repeat-containing protein 51</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>61625</th>
      <td>9606</td>
      <td>120356740</td>
      <td>TOMT</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>11</td>
      <td>-</td>
      <td>transmembrane O-methyltransferase</td>
      <td>protein-coding</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>transmembrane O-methyltransferase</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
  </tbody>
</table>
<p>5758 rows × 16 columns</p>
</div>




```python
df[ ~(df['chromosome'] == '10')  ]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>9606</td>
      <td>1</td>
      <td>A1BG</td>
      <td>-</td>
      <td>A1B|ABG|GAB|HYST2477</td>
      <td>MIM:138670|HGNC:HGNC:5|Ensembl:ENSG00000121410</td>
      <td>19</td>
      <td>19q13.43</td>
      <td>alpha-1-B glycoprotein</td>
      <td>protein-coding</td>
      <td>A1BG</td>
      <td>alpha-1-B glycoprotein</td>
      <td>O</td>
      <td>alpha-1B-glycoprotein|HEL-S-163pA|epididymis s...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>1</th>
      <td>9606</td>
      <td>2</td>
      <td>A2M</td>
      <td>-</td>
      <td>A2MD|CPAMD5|FWP007|S863-7</td>
      <td>MIM:103950|HGNC:HGNC:7|Ensembl:ENSG00000175899</td>
      <td>12</td>
      <td>12p13.31</td>
      <td>alpha-2-macroglobulin</td>
      <td>protein-coding</td>
      <td>A2M</td>
      <td>alpha-2-macroglobulin</td>
      <td>O</td>
      <td>alpha-2-macroglobulin|C3 and PZP-like alpha-2-...</td>
      <td>20210316</td>
      <td>-</td>
    </tr>
    <tr>
      <th>2</th>
      <td>9606</td>
      <td>3</td>
      <td>A2MP1</td>
      <td>-</td>
      <td>A2MP</td>
      <td>HGNC:HGNC:8|Ensembl:ENSG00000256069</td>
      <td>12</td>
      <td>12p13.31</td>
      <td>alpha-2-macroglobulin pseudogene 1</td>
      <td>pseudo</td>
      <td>A2MP1</td>
      <td>alpha-2-macroglobulin pseudogene 1</td>
      <td>O</td>
      <td>pregnancy-zone protein pseudogene</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>3</th>
      <td>9606</td>
      <td>9</td>
      <td>NAT1</td>
      <td>-</td>
      <td>AAC1|MNAT|NAT-1|NATI</td>
      <td>MIM:108345|HGNC:HGNC:7645|Ensembl:ENSG00000171428</td>
      <td>8</td>
      <td>8p22</td>
      <td>N-acetyltransferase 1</td>
      <td>protein-coding</td>
      <td>NAT1</td>
      <td>N-acetyltransferase 1</td>
      <td>O</td>
      <td>arylamine N-acetyltransferase 1|N-acetyltransf...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>4</th>
      <td>9606</td>
      <td>10</td>
      <td>NAT2</td>
      <td>-</td>
      <td>AAC2|NAT-2|PNAT</td>
      <td>MIM:612182|HGNC:HGNC:7646|Ensembl:ENSG00000156006</td>
      <td>8</td>
      <td>8p22</td>
      <td>N-acetyltransferase 2</td>
      <td>protein-coding</td>
      <td>NAT2</td>
      <td>N-acetyltransferase 2</td>
      <td>O</td>
      <td>arylamine N-acetyltransferase 2|N-acetyltransf...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>61713</th>
      <td>741158</td>
      <td>8923215</td>
      <td>trnD</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>tRNA</td>
      <td>tRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20200909</td>
      <td>-</td>
    </tr>
    <tr>
      <th>61714</th>
      <td>741158</td>
      <td>8923216</td>
      <td>trnP</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>tRNA</td>
      <td>tRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20200909</td>
      <td>-</td>
    </tr>
    <tr>
      <th>61715</th>
      <td>741158</td>
      <td>8923217</td>
      <td>trnA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>tRNA</td>
      <td>tRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20200909</td>
      <td>-</td>
    </tr>
    <tr>
      <th>61716</th>
      <td>741158</td>
      <td>8923218</td>
      <td>COX1</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>cytochrome c oxidase subunit I</td>
      <td>protein-coding</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>cytochrome c oxidase subunit I</td>
      <td>20200909</td>
      <td>-</td>
    </tr>
    <tr>
      <th>61717</th>
      <td>741158</td>
      <td>8923219</td>
      <td>16S rRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>l-rRNA</td>
      <td>rRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20200909</td>
      <td>-</td>
    </tr>
  </tbody>
</table>
<p>59256 rows × 16 columns</p>
</div>




```python
df[df['chromosome'].isin(['1', '3', '5'])]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>7</th>
      <td>9606</td>
      <td>13</td>
      <td>AADAC</td>
      <td>-</td>
      <td>CES5A1|DAC</td>
      <td>MIM:600338|HGNC:HGNC:17|Ensembl:ENSG00000114771</td>
      <td>3</td>
      <td>3q25.1</td>
      <td>arylacetamide deacetylase</td>
      <td>protein-coding</td>
      <td>AADAC</td>
      <td>arylacetamide deacetylase</td>
      <td>O</td>
      <td>arylacetamide deacetylase|arylacetamide deacet...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>18</th>
      <td>9606</td>
      <td>24</td>
      <td>ABCA4</td>
      <td>-</td>
      <td>ABC10|ABCR|ARMD2|CORD3|FFM|RMP|RP19|STGD|STGD1</td>
      <td>MIM:601691|HGNC:HGNC:34|Ensembl:ENSG00000198691</td>
      <td>1</td>
      <td>1p22.1</td>
      <td>ATP binding cassette subfamily A member 4</td>
      <td>protein-coding</td>
      <td>ABCA4</td>
      <td>ATP binding cassette subfamily A member 4</td>
      <td>O</td>
      <td>retinal-specific phospholipid-transporting ATP...</td>
      <td>20210316</td>
      <td>-</td>
    </tr>
    <tr>
      <th>21</th>
      <td>9606</td>
      <td>27</td>
      <td>ABL2</td>
      <td>-</td>
      <td>ABLL|ARG</td>
      <td>MIM:164690|HGNC:HGNC:77|Ensembl:ENSG00000143322</td>
      <td>1</td>
      <td>1q25.2</td>
      <td>ABL proto-oncogene 2, non-receptor tyrosine ki...</td>
      <td>protein-coding</td>
      <td>ABL2</td>
      <td>ABL proto-oncogene 2, non-receptor tyrosine ki...</td>
      <td>O</td>
      <td>tyrosine-protein kinase ABL2|Abelson tyrosine-...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>24</th>
      <td>9606</td>
      <td>30</td>
      <td>ACAA1</td>
      <td>-</td>
      <td>ACAA|PTHIO|THIO</td>
      <td>MIM:604054|HGNC:HGNC:82|Ensembl:ENSG00000060971</td>
      <td>3</td>
      <td>3p22.2</td>
      <td>acetyl-CoA acyltransferase 1</td>
      <td>protein-coding</td>
      <td>ACAA1</td>
      <td>acetyl-CoA acyltransferase 1</td>
      <td>O</td>
      <td>3-ketoacyl-CoA thiolase, peroxisomal|acetyl-Co...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>28</th>
      <td>9606</td>
      <td>34</td>
      <td>ACADM</td>
      <td>-</td>
      <td>ACAD1|MCAD|MCADH</td>
      <td>MIM:607008|HGNC:HGNC:89|Ensembl:ENSG00000117054</td>
      <td>1</td>
      <td>1p31.1</td>
      <td>acyl-CoA dehydrogenase medium chain</td>
      <td>protein-coding</td>
      <td>ACADM</td>
      <td>acyl-CoA dehydrogenase medium chain</td>
      <td>O</td>
      <td>medium-chain specific acyl-CoA dehydrogenase, ...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>61613</th>
      <td>9606</td>
      <td>120017342</td>
      <td>CZIB-DT</td>
      <td>-</td>
      <td>-</td>
      <td>HGNC:HGNC:55408</td>
      <td>1</td>
      <td>1p32.3</td>
      <td>CZIB divergent transcript</td>
      <td>ncRNA</td>
      <td>CZIB-DT</td>
      <td>CZIB divergent transcript</td>
      <td>O</td>
      <td>-</td>
      <td>20210220</td>
      <td>-</td>
    </tr>
    <tr>
      <th>61617</th>
      <td>9606</td>
      <td>120285837</td>
      <td>LOC120285837</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>5</td>
      <td>-</td>
      <td>VISTA enhancer hs2610</td>
      <td>biological-region</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20210205</td>
      <td>-</td>
    </tr>
    <tr>
      <th>61621</th>
      <td>9606</td>
      <td>120285841</td>
      <td>LOC120285841</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>3</td>
      <td>-</td>
      <td>VISTA enhancer hs2619</td>
      <td>biological-region</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20210205</td>
      <td>-</td>
    </tr>
    <tr>
      <th>61643</th>
      <td>9606</td>
      <td>120766157</td>
      <td>LOC120766157</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>1</td>
      <td>1p</td>
      <td>negCOR silencer S3</td>
      <td>biological-region</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20210318</td>
      <td>regulatory:silencer</td>
    </tr>
    <tr>
      <th>61644</th>
      <td>9606</td>
      <td>120766158</td>
      <td>LOC120766158</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>1</td>
      <td>1q</td>
      <td>negCOR silencer S4</td>
      <td>biological-region</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20210318</td>
      <td>regulatory:silencer</td>
    </tr>
  </tbody>
</table>
<p>12069 rows × 16 columns</p>
</div>




```python
a = [
    {'col_1': 1, 'col_2': 2, 'col_3': 10}, 
    {'col_1': 2, 'col_2': 2, 'col_3': 11}, 
    {'col_1': 3, 'col_2': 1, 'col_3': 12}, 
    {'col_1': 1, 'col_2': 4, 'col_3': 13}, 
    {'col_1': 2, 'col_2': 2, 'col_3': 14}, 
]
```


```python
pd.DataFrame(a)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>col_1</th>
      <th>col_2</th>
      <th>col_3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>2</td>
      <td>10</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>2</td>
      <td>11</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>1</td>
      <td>12</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>4</td>
      <td>13</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2</td>
      <td>2</td>
      <td>14</td>
    </tr>
  </tbody>
</table>
</div>




```python
b = {
    'col_1': [1,2,3,2,1],
    'col_2': [2,2,1,4,2],
    'col_3': [10, 11, 12,13,14],
}
```


```python
d  = pd.DataFrame(b)
```


```python
d
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>col_1</th>
      <th>col_2</th>
      <th>col_3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>2</td>
      <td>10</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>2</td>
      <td>11</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>1</td>
      <td>12</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2</td>
      <td>4</td>
      <td>13</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>2</td>
      <td>14</td>
    </tr>
  </tbody>
</table>
</div>




```python
d.to_excel('test.xlsx')
```


```python
pd.read_excel('test2.xlsx')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>col_1</th>
      <th>col_2</th>
      <th>col_3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>10</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>2</td>
      <td>2</td>
      <td>11</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>3</td>
      <td>1</td>
      <td>12</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>2</td>
      <td>4</td>
      <td>13</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>1</td>
      <td>2</td>
      <td>14</td>
    </tr>
    <tr>
      <th>5</th>
      <td>10</td>
      <td>5</td>
      <td>5</td>
      <td>6</td>
    </tr>
    <tr>
      <th>6</th>
      <td>16</td>
      <td>6</td>
      <td>8</td>
      <td>9</td>
    </tr>
  </tbody>
</table>
</div>




```python
dfs = pd.read_html('https://en.wikipedia.org/wiki/List_of_cities_and_towns_in_Greece')
```


```python
dfs[0]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rank</th>
      <th>City</th>
      <th>Census 1991</th>
      <th>Census 2001</th>
      <th>Census 2011</th>
      <th>Region</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Athens 1 *</td>
      <td>772072</td>
      <td>745514</td>
      <td>664046</td>
      <td>Attica</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Thessaloniki 2 *</td>
      <td>383967</td>
      <td>363987</td>
      <td>315196</td>
      <td>Central Macedonia</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Patras 8 *</td>
      <td>152570</td>
      <td>160400</td>
      <td>167446</td>
      <td>Western Greece</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Piraeus 1,3</td>
      <td>182671</td>
      <td>175697</td>
      <td>163688</td>
      <td>Attica</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Larissa</td>
      <td>112777</td>
      <td>124394</td>
      <td>144651</td>
      <td>Thessaly</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>139</th>
      <td>140</td>
      <td>Mandra 4</td>
      <td>10012</td>
      <td>10947</td>
      <td>11327</td>
      <td>Attica</td>
    </tr>
    <tr>
      <th>140</th>
      <td>141</td>
      <td>Tyrnavos</td>
      <td>12028</td>
      <td>11116</td>
      <td>11069</td>
      <td>Thessaly</td>
    </tr>
    <tr>
      <th>141</th>
      <td>142</td>
      <td>Glyka Nera 1</td>
      <td>5813</td>
      <td>6623</td>
      <td>11049</td>
      <td>Attica</td>
    </tr>
    <tr>
      <th>142</th>
      <td>143</td>
      <td>Ymittos 1</td>
      <td>11671</td>
      <td>11139</td>
      <td>10715</td>
      <td>Attica</td>
    </tr>
    <tr>
      <th>143</th>
      <td>144</td>
      <td>Neo Psychiko 1</td>
      <td>12023</td>
      <td>10848</td>
      <td>10137</td>
      <td>Attica</td>
    </tr>
  </tbody>
</table>
<p>144 rows × 6 columns</p>
</div>




```python
dfs[2]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>vteList of towns in Europe</th>
      <th>vteList of towns in Europe.1</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Sovereign states</td>
      <td>Albania Andorra Armenia Austria Azerbaijan Bel...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>States with limitedrecognition</td>
      <td>Abkhazia Artsakh Kosovo Northern Cyprus South ...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Dependencies andother entities</td>
      <td>Åland Faroe Islands Gibraltar Guernsey Isle of...</td>
    </tr>
  </tbody>
</table>
</div>




```python
def f(x):
    return 'gene_' + x['Symbol']


df['GENE2'] = df.apply(f, axis=1)
```


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
      <th>GENE2</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>9606</td>
      <td>1</td>
      <td>A1BG</td>
      <td>-</td>
      <td>A1B|ABG|GAB|HYST2477</td>
      <td>MIM:138670|HGNC:HGNC:5|Ensembl:ENSG00000121410</td>
      <td>19</td>
      <td>19q13.43</td>
      <td>alpha-1-B glycoprotein</td>
      <td>protein-coding</td>
      <td>A1BG</td>
      <td>alpha-1-B glycoprotein</td>
      <td>O</td>
      <td>alpha-1B-glycoprotein|HEL-S-163pA|epididymis s...</td>
      <td>20210302</td>
      <td>-</td>
      <td>gene_A1BG</td>
    </tr>
    <tr>
      <th>1</th>
      <td>9606</td>
      <td>2</td>
      <td>A2M</td>
      <td>-</td>
      <td>A2MD|CPAMD5|FWP007|S863-7</td>
      <td>MIM:103950|HGNC:HGNC:7|Ensembl:ENSG00000175899</td>
      <td>12</td>
      <td>12p13.31</td>
      <td>alpha-2-macroglobulin</td>
      <td>protein-coding</td>
      <td>A2M</td>
      <td>alpha-2-macroglobulin</td>
      <td>O</td>
      <td>alpha-2-macroglobulin|C3 and PZP-like alpha-2-...</td>
      <td>20210316</td>
      <td>-</td>
      <td>gene_A2M</td>
    </tr>
    <tr>
      <th>2</th>
      <td>9606</td>
      <td>3</td>
      <td>A2MP1</td>
      <td>-</td>
      <td>A2MP</td>
      <td>HGNC:HGNC:8|Ensembl:ENSG00000256069</td>
      <td>12</td>
      <td>12p13.31</td>
      <td>alpha-2-macroglobulin pseudogene 1</td>
      <td>pseudo</td>
      <td>A2MP1</td>
      <td>alpha-2-macroglobulin pseudogene 1</td>
      <td>O</td>
      <td>pregnancy-zone protein pseudogene</td>
      <td>20210302</td>
      <td>-</td>
      <td>gene_A2MP1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>9606</td>
      <td>9</td>
      <td>NAT1</td>
      <td>-</td>
      <td>AAC1|MNAT|NAT-1|NATI</td>
      <td>MIM:108345|HGNC:HGNC:7645|Ensembl:ENSG00000171428</td>
      <td>8</td>
      <td>8p22</td>
      <td>N-acetyltransferase 1</td>
      <td>protein-coding</td>
      <td>NAT1</td>
      <td>N-acetyltransferase 1</td>
      <td>O</td>
      <td>arylamine N-acetyltransferase 1|N-acetyltransf...</td>
      <td>20210302</td>
      <td>-</td>
      <td>gene_NAT1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>9606</td>
      <td>10</td>
      <td>NAT2</td>
      <td>-</td>
      <td>AAC2|NAT-2|PNAT</td>
      <td>MIM:612182|HGNC:HGNC:7646|Ensembl:ENSG00000156006</td>
      <td>8</td>
      <td>8p22</td>
      <td>N-acetyltransferase 2</td>
      <td>protein-coding</td>
      <td>NAT2</td>
      <td>N-acetyltransferase 2</td>
      <td>O</td>
      <td>arylamine N-acetyltransferase 2|N-acetyltransf...</td>
      <td>20210302</td>
      <td>-</td>
      <td>gene_NAT2</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>61713</th>
      <td>741158</td>
      <td>8923215</td>
      <td>trnD</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>tRNA</td>
      <td>tRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20200909</td>
      <td>-</td>
      <td>gene_trnD</td>
    </tr>
    <tr>
      <th>61714</th>
      <td>741158</td>
      <td>8923216</td>
      <td>trnP</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>tRNA</td>
      <td>tRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20200909</td>
      <td>-</td>
      <td>gene_trnP</td>
    </tr>
    <tr>
      <th>61715</th>
      <td>741158</td>
      <td>8923217</td>
      <td>trnA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>tRNA</td>
      <td>tRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20200909</td>
      <td>-</td>
      <td>gene_trnA</td>
    </tr>
    <tr>
      <th>61716</th>
      <td>741158</td>
      <td>8923218</td>
      <td>COX1</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>cytochrome c oxidase subunit I</td>
      <td>protein-coding</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>cytochrome c oxidase subunit I</td>
      <td>20200909</td>
      <td>-</td>
      <td>gene_COX1</td>
    </tr>
    <tr>
      <th>61717</th>
      <td>741158</td>
      <td>8923219</td>
      <td>16S rRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>l-rRNA</td>
      <td>rRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20200909</td>
      <td>-</td>
      <td>gene_16S rRNA</td>
    </tr>
  </tbody>
</table>
<p>61718 rows × 17 columns</p>
</div>




```python
df = df.drop('GENE2', 1)
```


```python
df.columns
```




    Index(['#tax_id', 'GeneID', 'Symbol', 'LocusTag', 'Synonyms', 'dbXrefs',
           'chromosome', 'map_location', 'description', 'type_of_gene',
           'Symbol_from_nomenclature_authority',
           'Full_name_from_nomenclature_authority', 'Nomenclature_status',
           'Other_designations', 'Modification_date', 'Feature_type'],
          dtype='object')




```python
d
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>col_1</th>
      <th>col_2</th>
      <th>col_3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>2</td>
      <td>10</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>2</td>
      <td>11</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>1</td>
      <td>12</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2</td>
      <td>4</td>
      <td>13</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>2</td>
      <td>14</td>
    </tr>
  </tbody>
</table>
</div>




```python
d.to_dict('index')
```




    {0: {'col_1': 1, 'col_2': 2, 'col_3': 10},
     1: {'col_1': 2, 'col_2': 2, 'col_3': 11},
     2: {'col_1': 3, 'col_2': 1, 'col_3': 12},
     3: {'col_1': 2, 'col_2': 4, 'col_3': 13},
     4: {'col_1': 1, 'col_2': 2, 'col_3': 14}}




```python
d.to_dict('records')
```




    [{'col_1': 1, 'col_2': 2, 'col_3': 10},
     {'col_1': 2, 'col_2': 2, 'col_3': 11},
     {'col_1': 3, 'col_2': 1, 'col_3': 12},
     {'col_1': 2, 'col_2': 4, 'col_3': 13},
     {'col_1': 1, 'col_2': 2, 'col_3': 14}]




```python
for row in df.itertuples():
    print (row.Symbol)
    break
```

    A1BG



```python
df.columns
```




    Index(['#tax_id', 'GeneID', 'Symbol', 'LocusTag', 'Synonyms', 'dbXrefs',
           'chromosome', 'map_location', 'description', 'type_of_gene',
           'Symbol_from_nomenclature_authority',
           'Full_name_from_nomenclature_authority', 'Nomenclature_status',
           'Other_designations', 'Modification_date', 'Feature_type'],
          dtype='object')




```python
d
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>col_1</th>
      <th>col_2</th>
      <th>col_3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>2</td>
      <td>10</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>2</td>
      <td>11</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>1</td>
      <td>12</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2</td>
      <td>4</td>
      <td>13</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>2</td>
      <td>14</td>
    </tr>
  </tbody>
</table>
</div>




```python
import random

b = {
    'col_1': [random.randint(1,4) for x in range(20)],
    'col_2': [random.randint(1,4) for x in range(20)],
    'col_3': [random.randint(1,4) for x in range(20)],
}
```


```python
d = pd.DataFrame(b)
```


```python
d
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>col_1</th>
      <th>col_2</th>
      <th>col_3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>4</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>1</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>3</td>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>4</td>
      <td>1</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1</td>
      <td>4</td>
      <td>3</td>
    </tr>
    <tr>
      <th>6</th>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>7</th>
      <td>4</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>8</th>
      <td>2</td>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>9</th>
      <td>3</td>
      <td>1</td>
      <td>3</td>
    </tr>
    <tr>
      <th>10</th>
      <td>1</td>
      <td>3</td>
      <td>2</td>
    </tr>
    <tr>
      <th>11</th>
      <td>3</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>12</th>
      <td>2</td>
      <td>2</td>
      <td>3</td>
    </tr>
    <tr>
      <th>13</th>
      <td>4</td>
      <td>3</td>
      <td>4</td>
    </tr>
    <tr>
      <th>14</th>
      <td>2</td>
      <td>4</td>
      <td>3</td>
    </tr>
    <tr>
      <th>15</th>
      <td>1</td>
      <td>4</td>
      <td>3</td>
    </tr>
    <tr>
      <th>16</th>
      <td>4</td>
      <td>2</td>
      <td>3</td>
    </tr>
    <tr>
      <th>17</th>
      <td>3</td>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>18</th>
      <td>1</td>
      <td>4</td>
      <td>2</td>
    </tr>
    <tr>
      <th>19</th>
      <td>1</td>
      <td>3</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
d.groupby('col_1')[['col_1']].aggregate('count')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>col_1</th>
    </tr>
    <tr>
      <th>col_1</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>7</td>
    </tr>
    <tr>
      <th>2</th>
      <td>5</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>




```python
d.groupby('col_1')[['col_2']].aggregate('min')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>col_2</th>
    </tr>
    <tr>
      <th>col_1</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>3</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>




```python
d.groupby('col_1')[['col_2', 'col_3']].aggregate('min')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>col_2</th>
      <th>col_3</th>
    </tr>
    <tr>
      <th>col_1</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
d.groupby('col_1')[['col_2', 'col_3']].aggregate({'col_2':'mean', 'col_3':'max'})
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>col_2</th>
      <th>col_3</th>
    </tr>
    <tr>
      <th>col_1</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>3.571429</td>
      <td>3</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2.000000</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1.333333</td>
      <td>3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2.600000</td>
      <td>4</td>
    </tr>
  </tbody>
</table>
</div>




```python
d.groupby(['col_1', 'col_2'])[['col_3']].aggregate('min')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>col_3</th>
    </tr>
    <tr>
      <th>col_1</th>
      <th>col_2</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="2" valign="top">1</th>
      <th>3</th>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
    </tr>
    <tr>
      <th rowspan="3" valign="top">2</th>
      <th>1</th>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3</td>
    </tr>
    <tr>
      <th rowspan="2" valign="top">3</th>
      <th>1</th>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
    </tr>
    <tr>
      <th rowspan="2" valign="top">4</th>
      <th>2</th>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.columns
```




    Index(['#tax_id', 'GeneID', 'Symbol', 'LocusTag', 'Synonyms', 'dbXrefs',
           'chromosome', 'map_location', 'description', 'type_of_gene',
           'Symbol_from_nomenclature_authority',
           'Full_name_from_nomenclature_authority', 'Nomenclature_status',
           'Other_designations', 'Modification_date', 'Feature_type'],
          dtype='object')




```python
df.groupby(['chromosome', 'type_of_gene'])['chromosome', 'type_of_gene'].aggregate('count')
```

    <ipython-input-118-73a1318ec552>:1: FutureWarning: Indexing with multiple keys (implicitly converted to a tuple of keys) will be deprecated, use a list instead.
      df.groupby(['chromosome', 'type_of_gene'])['chromosome', 'type_of_gene'].aggregate('count')





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>chromosome</th>
      <th>type_of_gene</th>
    </tr>
    <tr>
      <th>chromosome</th>
      <th>type_of_gene</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="5" valign="top">-</th>
      <th>ncRNA</th>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>other</th>
      <td>3</td>
      <td>3</td>
    </tr>
    <tr>
      <th>protein-coding</th>
      <td>13</td>
      <td>13</td>
    </tr>
    <tr>
      <th>pseudo</th>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>unknown</th>
      <td>128</td>
      <td>128</td>
    </tr>
    <tr>
      <th>...</th>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th rowspan="5" valign="top">Y</th>
      <th>ncRNA</th>
      <td>107</td>
      <td>107</td>
    </tr>
    <tr>
      <th>other</th>
      <td>29</td>
      <td>29</td>
    </tr>
    <tr>
      <th>protein-coding</th>
      <td>46</td>
      <td>46</td>
    </tr>
    <tr>
      <th>pseudo</th>
      <td>389</td>
      <td>389</td>
    </tr>
    <tr>
      <th>unknown</th>
      <td>6</td>
      <td>6</td>
    </tr>
  </tbody>
</table>
<p>226 rows × 2 columns</p>
</div>




```python
d
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>col_1</th>
      <th>col_2</th>
      <th>col_3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>4</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>1</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>3</td>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>4</td>
      <td>1</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1</td>
      <td>4</td>
      <td>3</td>
    </tr>
    <tr>
      <th>6</th>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>7</th>
      <td>4</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>8</th>
      <td>2</td>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>9</th>
      <td>3</td>
      <td>1</td>
      <td>3</td>
    </tr>
    <tr>
      <th>10</th>
      <td>1</td>
      <td>3</td>
      <td>2</td>
    </tr>
    <tr>
      <th>11</th>
      <td>3</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>12</th>
      <td>2</td>
      <td>2</td>
      <td>3</td>
    </tr>
    <tr>
      <th>13</th>
      <td>4</td>
      <td>3</td>
      <td>4</td>
    </tr>
    <tr>
      <th>14</th>
      <td>2</td>
      <td>4</td>
      <td>3</td>
    </tr>
    <tr>
      <th>15</th>
      <td>1</td>
      <td>4</td>
      <td>3</td>
    </tr>
    <tr>
      <th>16</th>
      <td>4</td>
      <td>2</td>
      <td>3</td>
    </tr>
    <tr>
      <th>17</th>
      <td>3</td>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>18</th>
      <td>1</td>
      <td>4</td>
      <td>2</td>
    </tr>
    <tr>
      <th>19</th>
      <td>1</td>
      <td>3</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
d['col_1'].value_counts()
```




    1    7
    4    5
    2    5
    3    3
    Name: col_1, dtype: int64




```python
df['chromosome'].value_counts().plot(kind='bar')
```




    <AxesSubplot:>




    
![png](output_65_1.png)
    



```python
df['chromosome'].value_counts().plot(kind='pie')
```




    <AxesSubplot:ylabel='chromosome'>




    
![png](output_66_1.png)
    



```python
# Why piechart are bad for data visualization 
```


```python
d
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>col_1</th>
      <th>col_2</th>
      <th>col_3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>4</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>1</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>3</td>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>4</td>
      <td>1</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1</td>
      <td>4</td>
      <td>3</td>
    </tr>
    <tr>
      <th>6</th>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>7</th>
      <td>4</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>8</th>
      <td>2</td>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>9</th>
      <td>3</td>
      <td>1</td>
      <td>3</td>
    </tr>
    <tr>
      <th>10</th>
      <td>1</td>
      <td>3</td>
      <td>2</td>
    </tr>
    <tr>
      <th>11</th>
      <td>3</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>12</th>
      <td>2</td>
      <td>2</td>
      <td>3</td>
    </tr>
    <tr>
      <th>13</th>
      <td>4</td>
      <td>3</td>
      <td>4</td>
    </tr>
    <tr>
      <th>14</th>
      <td>2</td>
      <td>4</td>
      <td>3</td>
    </tr>
    <tr>
      <th>15</th>
      <td>1</td>
      <td>4</td>
      <td>3</td>
    </tr>
    <tr>
      <th>16</th>
      <td>4</td>
      <td>2</td>
      <td>3</td>
    </tr>
    <tr>
      <th>17</th>
      <td>3</td>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>18</th>
      <td>1</td>
      <td>4</td>
      <td>2</td>
    </tr>
    <tr>
      <th>19</th>
      <td>1</td>
      <td>3</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
d.plot.scatter(x='col_1', y='col_2')
```




    <AxesSubplot:xlabel='col_1', ylabel='col_2'>




    
![png](output_69_1.png)
    



```python
d['col_1'].plot()
```




    <AxesSubplot:>




    
![png](output_70_1.png)
    



```python
d['col_1']
```




    0     4
    1     1
    2     2
    3     4
    4     1
    5     1
    6     2
    7     4
    8     2
    9     3
    10    1
    11    3
    12    2
    13    4
    14    2
    15    1
    16    4
    17    3
    18    1
    19    1
    Name: col_1, dtype: int64




```python
d[['col_1', 'col_2']].plot()
```




    <AxesSubplot:>




    
![png](output_72_1.png)
    



```python
d
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>col_1</th>
      <th>col_2</th>
      <th>col_3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>4</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>1</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>3</td>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>4</td>
      <td>1</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1</td>
      <td>4</td>
      <td>3</td>
    </tr>
    <tr>
      <th>6</th>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>7</th>
      <td>4</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>8</th>
      <td>2</td>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>9</th>
      <td>3</td>
      <td>1</td>
      <td>3</td>
    </tr>
    <tr>
      <th>10</th>
      <td>1</td>
      <td>3</td>
      <td>2</td>
    </tr>
    <tr>
      <th>11</th>
      <td>3</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>12</th>
      <td>2</td>
      <td>2</td>
      <td>3</td>
    </tr>
    <tr>
      <th>13</th>
      <td>4</td>
      <td>3</td>
      <td>4</td>
    </tr>
    <tr>
      <th>14</th>
      <td>2</td>
      <td>4</td>
      <td>3</td>
    </tr>
    <tr>
      <th>15</th>
      <td>1</td>
      <td>4</td>
      <td>3</td>
    </tr>
    <tr>
      <th>16</th>
      <td>4</td>
      <td>2</td>
      <td>3</td>
    </tr>
    <tr>
      <th>17</th>
      <td>3</td>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>18</th>
      <td>1</td>
      <td>4</td>
      <td>2</td>
    </tr>
    <tr>
      <th>19</th>
      <td>1</td>
      <td>3</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
d2 = d.sort_values('col_1')
```


```python
d2.plot(x='col_1', y='col_2')
```




    <AxesSubplot:xlabel='col_1'>




    
![png](output_75_1.png)
    



```python
d2
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>col_1</th>
      <th>col_2</th>
      <th>col_3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>19</th>
      <td>1</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>4</td>
      <td>1</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1</td>
      <td>4</td>
      <td>3</td>
    </tr>
    <tr>
      <th>15</th>
      <td>1</td>
      <td>4</td>
      <td>3</td>
    </tr>
    <tr>
      <th>18</th>
      <td>1</td>
      <td>4</td>
      <td>2</td>
    </tr>
    <tr>
      <th>10</th>
      <td>1</td>
      <td>3</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>1</td>
      <td>3</td>
    </tr>
    <tr>
      <th>6</th>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>8</th>
      <td>2</td>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>14</th>
      <td>2</td>
      <td>4</td>
      <td>3</td>
    </tr>
    <tr>
      <th>12</th>
      <td>2</td>
      <td>2</td>
      <td>3</td>
    </tr>
    <tr>
      <th>17</th>
      <td>3</td>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>9</th>
      <td>3</td>
      <td>1</td>
      <td>3</td>
    </tr>
    <tr>
      <th>11</th>
      <td>3</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>7</th>
      <td>4</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>16</th>
      <td>4</td>
      <td>2</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>3</td>
      <td>2</td>
    </tr>
    <tr>
      <th>13</th>
      <td>4</td>
      <td>3</td>
      <td>4</td>
    </tr>
    <tr>
      <th>0</th>
      <td>4</td>
      <td>3</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
e = pd.DataFrame({
    'x':[1,2,3,4,5,6,7,8,9,10],
    'y':[1,2,3,2,3,4,3,4,5,4,],
})
```


```python
e.plot(x='x', y='y')
```




    <AxesSubplot:xlabel='x'>




    
![png](output_78_1.png)
    



```python
gwas = pd.read_csv('https://www.ebi.ac.uk/gwas/api/search/downloads/full', sep='\t')
```

    /Users/admin/anaconda3/lib/python3.8/site-packages/IPython/core/interactiveshell.py:3146: DtypeWarning: Columns (9,11,12,23,27) have mixed types.Specify dtype option on import or set low_memory=False.
      has_raised = await self.run_ast_nodes(code_ast.body, cell_name,



```python
gwas.shape
```




    (251401, 34)




```python
gwas[ (gwas["DISEASE/TRAIT"].str.contains('Breast')) & (
    gwas["PVALUE_MLOG"]>10)].groupby("CHR_ID")['CHR_ID'].aggregate('count').plot(kind='bar')
```




    <AxesSubplot:xlabel='CHR_ID'>




    
![png](output_81_1.png)
    



```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>9606</td>
      <td>1</td>
      <td>A1BG</td>
      <td>-</td>
      <td>A1B|ABG|GAB|HYST2477</td>
      <td>MIM:138670|HGNC:HGNC:5|Ensembl:ENSG00000121410</td>
      <td>19</td>
      <td>19q13.43</td>
      <td>alpha-1-B glycoprotein</td>
      <td>protein-coding</td>
      <td>A1BG</td>
      <td>alpha-1-B glycoprotein</td>
      <td>O</td>
      <td>alpha-1B-glycoprotein|HEL-S-163pA|epididymis s...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>1</th>
      <td>9606</td>
      <td>2</td>
      <td>A2M</td>
      <td>-</td>
      <td>A2MD|CPAMD5|FWP007|S863-7</td>
      <td>MIM:103950|HGNC:HGNC:7|Ensembl:ENSG00000175899</td>
      <td>12</td>
      <td>12p13.31</td>
      <td>alpha-2-macroglobulin</td>
      <td>protein-coding</td>
      <td>A2M</td>
      <td>alpha-2-macroglobulin</td>
      <td>O</td>
      <td>alpha-2-macroglobulin|C3 and PZP-like alpha-2-...</td>
      <td>20210316</td>
      <td>-</td>
    </tr>
    <tr>
      <th>2</th>
      <td>9606</td>
      <td>3</td>
      <td>A2MP1</td>
      <td>-</td>
      <td>A2MP</td>
      <td>HGNC:HGNC:8|Ensembl:ENSG00000256069</td>
      <td>12</td>
      <td>12p13.31</td>
      <td>alpha-2-macroglobulin pseudogene 1</td>
      <td>pseudo</td>
      <td>A2MP1</td>
      <td>alpha-2-macroglobulin pseudogene 1</td>
      <td>O</td>
      <td>pregnancy-zone protein pseudogene</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>3</th>
      <td>9606</td>
      <td>9</td>
      <td>NAT1</td>
      <td>-</td>
      <td>AAC1|MNAT|NAT-1|NATI</td>
      <td>MIM:108345|HGNC:HGNC:7645|Ensembl:ENSG00000171428</td>
      <td>8</td>
      <td>8p22</td>
      <td>N-acetyltransferase 1</td>
      <td>protein-coding</td>
      <td>NAT1</td>
      <td>N-acetyltransferase 1</td>
      <td>O</td>
      <td>arylamine N-acetyltransferase 1|N-acetyltransf...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>4</th>
      <td>9606</td>
      <td>10</td>
      <td>NAT2</td>
      <td>-</td>
      <td>AAC2|NAT-2|PNAT</td>
      <td>MIM:612182|HGNC:HGNC:7646|Ensembl:ENSG00000156006</td>
      <td>8</td>
      <td>8p22</td>
      <td>N-acetyltransferase 2</td>
      <td>protein-coding</td>
      <td>NAT2</td>
      <td>N-acetyltransferase 2</td>
      <td>O</td>
      <td>arylamine N-acetyltransferase 2|N-acetyltransf...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>61713</th>
      <td>741158</td>
      <td>8923215</td>
      <td>trnD</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>tRNA</td>
      <td>tRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20200909</td>
      <td>-</td>
    </tr>
    <tr>
      <th>61714</th>
      <td>741158</td>
      <td>8923216</td>
      <td>trnP</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>tRNA</td>
      <td>tRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20200909</td>
      <td>-</td>
    </tr>
    <tr>
      <th>61715</th>
      <td>741158</td>
      <td>8923217</td>
      <td>trnA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>tRNA</td>
      <td>tRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20200909</td>
      <td>-</td>
    </tr>
    <tr>
      <th>61716</th>
      <td>741158</td>
      <td>8923218</td>
      <td>COX1</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>cytochrome c oxidase subunit I</td>
      <td>protein-coding</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>cytochrome c oxidase subunit I</td>
      <td>20200909</td>
      <td>-</td>
    </tr>
    <tr>
      <th>61717</th>
      <td>741158</td>
      <td>8923219</td>
      <td>16S rRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>l-rRNA</td>
      <td>rRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20200909</td>
      <td>-</td>
    </tr>
  </tbody>
</table>
<p>61718 rows × 16 columns</p>
</div>




```python
gwas['c2']  = pd.to_datetime(gwas['DATE'])
```


```python
gwas['c2'] 
```




    0        2020-04-15
    1        2019-10-30
    2        2019-10-30
    3        2020-04-15
    4        2019-10-30
                ...    
    251396   2020-09-02
    251397   2020-09-02
    251398   2020-09-02
    251399   2020-09-02
    251400   2020-09-02
    Name: c2, Length: 251401, dtype: datetime64[ns]




```python

```


```python

```


```python

```


```python

```
